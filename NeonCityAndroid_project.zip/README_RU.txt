NEON CITY — Android-проект для сборки APK

Это Android Studio-проект, который открывает HTML-игру в полноэкранном WebView.
Важно: это НЕ готовый APK-файл. В этой среде нет Android SDK и Gradle, поэтому бинарный APK здесь собрать нельзя.

Как получить APK:
1. Установите Android Studio на компьютер.
2. Распакуйте архив NeonCityAndroid.zip.
3. В Android Studio выберите Open и укажите папку NeonCityAndroid.
4. Дождитесь Gradle Sync. При запросе установите Android SDK Platform 35.
5. Выберите Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK появится в app/build/outputs/apk/debug/app-debug.apk.
7. Перенесите APK на Android-телефон и установите. Если появится запрос, разрешите установку из этого источника.

Интернет:
- Текущая HTML-игра загружает Three.js с CDN, поэтому при первом запуске нужен интернет.
- Сам HTML встроен в приложение. Но 3D-библиотека пока не встроена локально.

Требования: Android Studio с JDK 17; Android SDK Platform 35.
